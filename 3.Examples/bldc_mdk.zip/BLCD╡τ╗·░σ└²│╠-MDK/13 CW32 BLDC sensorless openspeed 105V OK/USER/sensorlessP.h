
#define STEP_RAMP_SIZE 64

extern const unsigned char RAMP_TABLE[ STEP_RAMP_SIZE ] ;
