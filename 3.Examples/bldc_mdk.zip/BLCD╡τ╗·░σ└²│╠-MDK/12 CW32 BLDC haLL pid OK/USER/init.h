#include "MAIN.h" 
//#include "globalv.h"


void RCC_Configuration(void);
void ADC_Configuration(void);
void GPIOInit(void);
void BTIM_init(void);
void Usart3_init(void);
void Usart3_sendchar(unsigned char cs);
void Rec_Check(void);
