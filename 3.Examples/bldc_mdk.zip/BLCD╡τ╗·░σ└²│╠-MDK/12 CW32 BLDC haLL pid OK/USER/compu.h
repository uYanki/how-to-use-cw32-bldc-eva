#include "globalv.h"

void SampleSpeed(void);
void SampleVI(void);
