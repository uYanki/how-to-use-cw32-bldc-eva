
#define 	data0  	28017 
#define 	data1 	26826 
#define 	data2	25697 
#define 	data3	24629 
#define 	data4	23618 
#define 	data5	22660 
#define 	data6	21752 
#define 	data7	20892 
#define 	data8	20075 
#define 	data9	19299 
#define 	data10	18560 
#define 	data11	18482 
#define 	data12	18149 
#define 	data13	17632 
#define 	data14	16992 
#define 	data15	16280 
#define 	data16	15535 
#define 	data17	14787 
#define 	data18	14055 
#define 	data19	13354 
#define 	data20	12690 
#define 	data21	12068 
#define 	data22	11490 
#define 	data23	10954 
#define 	data24	10458 
#define 	data25	10000 
#define 	data26	9576 
#define 	data27	9184 
#define 	data28	8819 
#define 	data29	8478 
#define 	data30	8160 
#define 	data31	7861 
#define 	data32	7579 
#define 	data33	7311 
#define 	data34	7056 
#define 	data35	6813 
#define 	data36	6581 
#define 	data37	6357 
#define 	data38	6142 
#define 	data39	5934 
#define 	data40	5734 
#define 	data41	5541 
#define 	data42	5353 
#define 	data43	5173 
#define 	data44	4998 
#define 	data45	4829 
#define 	data46	4665 
#define 	data47	4507 
#define 	data48	4355 
#define 	data49	4208 
#define 	data50	4065 
#define 	data51	3927 
#define 	data52	3794 
#define 	data53	3664 
#define 	data54	3538 
#define 	data55	3415 
#define 	data56	3294 
#define 	data57	3175 
#define 	data58	3058 
#define 	data59	2941 
#define 	data60	2825 
#define 	data61	2776 
#define 	data62	2718 
#define 	data63	2652 
#define 	data64	2582 
#define 	data65	2508 
#define 	data66	2432 
#define 	data67	2356 
#define 	data68	2280 
#define 	data69	2207 
#define 	data70	2135 
#define 	data71	2066 
#define 	data72	2000 
#define 	data73	1938 
#define 	data74	1879 
#define 	data75	1823 
#define 	data76	1770 
#define 	data77	1720 
#define 	data78	1673 
#define 	data79	1628 
#define 	data80	1586 
#define 	data81	1546 
#define 	data82	1508 
#define 	data83	1471 
#define 	data84	1435 
#define 	data85	1401 
#define 	data86	1367 
#define 	data87	1334 
#define 	data88	1301 
#define 	data89	1268 
#define 	data90	1236 
#define 	data91	1204 
#define 	data92	1171 
#define 	data93	1139 
#define 	data94	1107 
#define 	data95	1074 
#define 	data96	1042 
#define 	data97	1010 

unsigned int  Table[98]={data0,
data1,
data2,
data3,
data4,
data5,
data6,
data7,
data8,
data9,
data10,
data11,
data12,
data13,
data14,
data15,
data16,
data17,
data18,
data19,
data20,
data21,
data22,
data23,
data24,
data25,
data26,
data27,
data28,
data29,
data30,
data31,
data32,
data33,
data34,
data35,
data36,
data37,
data38,
data39,
data40,
data41,
data42,
data43,
data44,
data45,
data46,
data47,
data48,
data49,
data50,
data51,
data52,
data53,
data54,
data55,
data56,
data57,
data58,
data59,
data60,
data61,
data62,
data63,
data64,
data65,
data66,
data67,
data68,
data69,
data70,
data71,
data72,
data73,
data74,
data75,
data76,
data77,
data78,
data79,
data80,
data81,
data82,
data83,
data84,
data85,
data86,
data87,
data88,
data89,
data90,
data91,
data92,
data93,
data94,
data95,
data96,
data97,
};
