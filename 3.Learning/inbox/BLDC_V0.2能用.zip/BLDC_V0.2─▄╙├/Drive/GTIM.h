#ifndef __GTIM_H
#define __GTIM_H

#include "cw32f030.h"

extern uint32_t PWMWidth;

void GTIM_init(void);

#endif
