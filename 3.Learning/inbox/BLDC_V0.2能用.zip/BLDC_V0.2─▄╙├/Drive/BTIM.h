#ifndef __BTIM_H
#define __BTIM_H

#include "cw32f030.h"

void BTIM1_init(void);
void delay_ms(uint16_t ms);
void SENSORLESS_TIM_Config(void);

#endif
