#ifndef __Uart1_H
#define __Uart1_H

#include "cw32f030.h"

void UART_Configuration(void);

#endif
