#include "cw32f030.h"

#pragma once
					    
//------------------------------------------------------------------------------------ 
void cwesc_uart_init(void);

uint16_t cwesc_uart_available(uint8_t port);
uint16_t cwesc_uart_used_tx_buff(void);

uint16_t cwesc_uart_read_buffer(uint8_t *buf, uint16_t length);
void cwesc_uart_write_buffer(uint8_t *buf, uint16_t length);




