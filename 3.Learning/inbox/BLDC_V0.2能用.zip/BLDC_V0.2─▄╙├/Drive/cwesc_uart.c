#include "cwesc_uart.h"
#include "uart1.h"

#include "cw32f030_uart.h"

#define CWESC_TX_BUFFER_SIZE        128
#define CWESC_RX_BUFFER_SIZE        128


uint8_t cwescSerialBufferTX[CWESC_TX_BUFFER_SIZE]; 
volatile uint16_t cwescSerialHeadTX=0, cwescSerialTailTX=0;
uint8_t cwescSerialBufferRX[CWESC_RX_BUFFER_SIZE];
volatile uint16_t cwescSerialHeadRX=0, cwescSerialTailRX = 0;

drv_uart_s cwescUart;

//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
void cwesc_uart_rx_callback(uint8_t c)
{	
	uint16_t h = cwescSerialHeadRX;
  
  if (++h >= CWESC_RX_BUFFER_SIZE) h = 0;
  if (h != cwescSerialTailRX) {
    cwescSerialBufferRX[cwescSerialHeadRX] = c;
    cwescSerialHeadRX = h;
  }  
}

void cwesc_uart_tx_callback(void)
{	
  uint16_t t = cwescSerialTailTX;
  
  if (t != cwescSerialHeadTX) { 
    if (++t >= CWESC_TX_BUFFER_SIZE) t = 0;
    drv_uart_transmit(cwescUart.COM_ID, cwescSerialBufferTX[cwescSerialTailTX]);
    cwescSerialTailTX = t;
  }
  
  if (t == cwescSerialHeadTX)              // Check if all data is transmitted . if yes disable transmitter UDRE interrupt
  {
    drv_uart_disable_int_tbe(cwescUart.COM_ID);
  }    
}


//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
//���ڳ�ʼ��
//------------------------------------------------------------------------------------------------
void cwesc_uart_init(void)
{
  cwescUart.COM_ID = COM_ID_0;
  cwescUart.baudrate = 115200;
  
  cwescUart.enable_int_rbne = 1;
  cwescUart.enable_int_tbe = 0;
  
  cwescUart.rx_callback = cwesc_uart_rx_callback;
  cwescUart.tx_callback = cwesc_uart_tx_callback;
  
  drv_uart_init(&cwescUart);
}


//========================================================================================================
//========================================================================================================
//----------------------------------------------------------------------------------
// �������ڷ����жϣ��жϺ����з�������
//----------------------------------------------------------------------------------
void cwesc_uart_send_start(void) {  
    drv_uart_enable_int_tbe(cwescUart.COM_ID); 
}

//----------------------------------------------------------------------------------
// ��д���ݻ�������������Ƿ��ͣ���û������Ӳ�����ڷ���
//----------------------------------------------------------------------------------
//static uint8_t _cwesc_serial_read(void) {
//  uint16_t t = cwescSerialTailRX;
//  uint8_t c = cwescSerialBufferRX[t];
//  if (cwescSerialHeadRX != t) {
//    if (++t >= CWESC_RX_BUFFER_SIZE) t = 0;
//    cwescSerialTailRX = t;
//  }
//  return c;
//}

static void _cwesc_serial_write(uint8_t a) {
  uint16_t t = cwescSerialHeadTX; 	
  if(++t >= CWESC_TX_BUFFER_SIZE) t = 0;	
	if(t != cwescSerialTailTX) {
    cwescSerialBufferTX[cwescSerialHeadTX] = a;
    cwescSerialHeadTX = t;
	}
}

uint16_t cwesc_uart_available(uint8_t port) 
{	
  return ((uint16_t)(cwescSerialHeadRX - cwescSerialTailRX))%CWESC_RX_BUFFER_SIZE;
} 
uint16_t cwesc_uart_used_tx_buff(void) 
{
  return ((uint16_t)(cwescSerialHeadTX - cwescSerialTailTX))%CWESC_TX_BUFFER_SIZE;
}

//----------------------------------------------------------------------------------
// д���ݵ�����
// 1) ��д����������  2)��ʹ�ܴ����ж�  3)�жϺ����з�������
//----------------------------------------------------------------------------------
void cwesc_uart_write(uint8_t c)
{
  _cwesc_serial_write(c);
	cwesc_uart_send_start();
}

void cwesc_uart_write_buffer(uint8_t *buf, uint16_t length)
{
	uint16_t i;	
	for(i=0; i<length; i++) {
		_cwesc_serial_write(buf[i]);
	}
	cwesc_uart_send_start();
}

uint16_t cwesc_uart_read_buffer(uint8_t *buf, uint16_t length)
{
	uint16_t i=0, t;	
	while(length) {
		t = cwescSerialTailRX;
		buf[i] = cwescSerialBufferRX[t];
    if (cwescSerialHeadRX != t) {
      if (++t >= CWESC_RX_BUFFER_SIZE) t = 0;
      cwescSerialTailRX = t;
		} else {
			break;
		}
		i++;
		length--;
	}
	return i;
}


//----------------------------------------------------------------------------------
//���ݴ�ӡ����
//----------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------
#include <stdio.h>

/* retarget the C library printf function to the USART */
int fputc(int ch, FILE *f)
{
  cwesc_uart_write(ch);
  return ch;
}




