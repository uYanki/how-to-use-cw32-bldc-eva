#ifndef __PID_H
#define __PID_H

#include "motorcontrol.h" 

void PID_init(void);
void PIDcompute(unsigned int Target,unsigned int Real);

#endif
