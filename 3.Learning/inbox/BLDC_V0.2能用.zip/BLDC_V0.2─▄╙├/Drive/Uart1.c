#include <stdio.h>
#include "Uart1.h"
#include "cw32f030_rcc.h"
#include "cw32f030_gpio.h"
#include "cw32f030_uart.h"

//UARTx
#define  DEBUG_USARTx                   CW_UART1
#define  DEBUG_USART_CLK                RCC_APB2_PERIPH_UART1
#define  DEBUG_USART_APBClkENx          RCC_APBPeriphClk_Enable2
#define  DEBUG_USART_BaudRate           115200
//#define  DEBUG_USART_UclkFreq         64000000

//UARTx GPIO
#define  DEBUG_USART_GPIO_CLK           RCC_AHB_PERIPH_GPIOA
#define  DEBUG_USART_TX_GPIO_PORT       CW_GPIOA   
#define  DEBUG_USART_TX_GPIO_PIN        GPIO_PIN_14
#define  DEBUG_USART_RX_GPIO_PORT       CW_GPIOA
#define  DEBUG_USART_RX_GPIO_PIN        GPIO_PIN_13

//GPIO AF
#define  DEBUG_USART_AFTX               PA14_AFx_UART1TXD()
#define  DEBUG_USART_AFRX               PA13_AFx_UART1RXD()

//�ж�
#define  DEBUG_USART_IRQ                UART1_IRQn

#define TX_BUFFER_SIZE      128
#define RX_BUFFER_SIZE      128

uint8_t TXBuffer[TX_BUFFER_SIZE];
uint8_t RXBuffer[RX_BUFFER_SIZE];

/**
 * @brief ����UART
 * 
 */
void UART_Configuration(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
  USART_InitTypeDef USART_InitStructure;
	
	//��PA13��PA14���ó�ͨ��GPIO����
  GPIO_SWD2GPIO();
	
	//����ʱ��ʹ��
  RCC_AHBPeriphClk_Enable(DEBUG_USART_GPIO_CLK, ENABLE);
	//����ʱ��ʹ��
  DEBUG_USART_APBClkENx(DEBUG_USART_CLK, ENABLE);
	
	//UART TX RX ���� 
  DEBUG_USART_AFTX;                     
  DEBUG_USART_AFRX;                     
  //GPIO����
  GPIO_InitStructure.Pins = DEBUG_USART_TX_GPIO_PIN;
  GPIO_InitStructure.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStructure.Speed = GPIO_SPEED_HIGH;
  GPIO_Init(DEBUG_USART_TX_GPIO_PORT, &GPIO_InitStructure);
  
  GPIO_InitStructure.Pins = DEBUG_USART_RX_GPIO_PIN;
  GPIO_InitStructure.Mode = GPIO_MODE_INPUT_PULLUP;
  GPIO_Init(DEBUG_USART_RX_GPIO_PORT, &GPIO_InitStructure);
	
  //���ڲ�������
  USART_InitStructure.USART_BaudRate = DEBUG_USART_BaudRate;
  USART_InitStructure.USART_Over = USART_Over_16;
  USART_InitStructure.USART_Source = USART_Source_PCLK;
  USART_InitStructure.USART_UclkFreq = SystemCoreClock;
  USART_InitStructure.USART_StartBit = USART_StartBit_FE;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No ;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(DEBUG_USARTx, &USART_InitStructure); 

  //���ȼ��������ȼ�����
  NVIC_SetPriority(DEBUG_USART_IRQ, 2);
  //UARTx�ж�ʹ��
  NVIC_EnableIRQ(DEBUG_USART_IRQ);	
	//ʹ��UARTx RC(�������)�ж�
  USART_ITConfig(DEBUG_USARTx, USART_IT_RC, ENABLE);
}

/**
 * @brief This funcation handles UART1
 */
void UART1_IRQHandler(void)
{
	//��������ж�
	if(USART_GetITStatus(DEBUG_USARTx, USART_IT_RC) != RESET)
  {
    USART_ClearITPendingBit(DEBUG_USARTx, USART_IT_RC);         
  }
	
	/*
  //���ͻ��������ж�
  if(USART_GetITStatus(DEBUG_USARTx, USART_IT_TXE) != RESET)
  {
    USART_ClearITPendingBit(DEBUG_USARTx, USART_IT_TXE);         
  }
	*/
}

/**/
int fputc(int ch, FILE *f)
{
  //UART_SendData(ch);
	USART_SendData_8bit(DEBUG_USARTx, (uint16_t)ch);
	while(USART_GetITStatus(DEBUG_USARTx, USART_IT_TXE) == RESET);
  return ch;
}
/**/
