#ifndef __MAIN_H
#define __MAIN_H

/* Includes ----------*/
#include "base_types.h"
#include "cw32f030.h"
#include "system_cw32f030.h"
#include "cw32f030_rcc.h"
#include "cw32f030_flash.h"

#define MotorPoles 7 //���������

extern unsigned int timecountpid;
extern unsigned int RealSpid,TargetS;  //�������ת�ٺ�Ŀ���ٶ�

extern unsigned int timecount,timecount1;  

void RCC_Configuration(void);

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT CW *****END OF FILE****/
